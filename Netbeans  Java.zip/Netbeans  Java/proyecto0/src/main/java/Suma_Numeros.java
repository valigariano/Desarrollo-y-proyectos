/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
import java .io.*;
import java.util.Scanner;
import java.lang.*;

public class Suma_Numeros {
    public static void main(String[] args){
         
        Scanner Teclado = new Scanner(System.in);
        System.out.println("Ingresa un numero");
        double sumado0=Teclado.nextDouble();
         System.out.println("Ingresa un numero");
        double sumado=Teclado.nextDouble();
         double operacion=sumado+sumado0;
        System.out.println("El resultado de la operacion es"+operacion);
        
    }
}