/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto0;
import java.io.*;
/**
 *
 * @author HP
 */
public class Proyecto0 {
            
            
             
    public static void main(String[] args) {
        
         float operador;
             float operador0;
              float resultado;
          operador=2;
          operador0=20;
          resultado=operador+operador0;
    System.out.println("El resultado de la operacion es:"+resultado);
        System.out.println("Hello World!");
    }
}
