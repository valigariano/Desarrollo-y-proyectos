/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.operaciones;

import java.util.Scanner;
import java.io.*;
import java.lang.*;
/**
 *
 * @author HP
 */
public class Operaciones {

    public static void main(String[] args) {
Scanner Teclado = new Scanner(System.in);
        System.out.println("Ingresa un numero");
double sumado0=Teclado.nextDouble();
         System.out.println("Ingresa un numero");
        double sumado=Teclado.nextDouble();
         double operacion=sumado+sumado0;
        System.out.println("El resultado de la operacion es"+operacion);
        System.out.println("Hello World!");
    }
}





//public class Suma_Numeros {
 //   public static void main(String[] args){
         
        
        
        
        
    
