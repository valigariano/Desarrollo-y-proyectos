#include <stdio.h>
#include <math.h>

#define PI 3.14159265358979323846

// Funciones para calcular �rea y per�metro
void calcularCuadrado() {
    double lado;
    printf("Ingresa el lado del cuadrado: ");
    scanf("%lf", &lado);
    printf("�rea: %.2lf\n", lado * lado);
    printf("Per�metro: %.2lf\n", 4 * lado);
}

void calcularRectangulo() {
    double largo, ancho;
    printf("Ingresa el largo del rect�ngulo: ");
    scanf("%lf", &largo);
    printf("Ingresa el ancho del rect�ngulo: ");
    scanf("%lf", &ancho);
    printf("�rea: %.2lf\n", largo * ancho);
    printf("Per�metro: %.2lf\n", 2 * (largo + ancho));
}

void calcularTriangulo() {
    double base, altura, a, b, c;
    printf("Ingresa la base del tri�ngulo: ");
    scanf("%lf", &base);
    printf("Ingresa la altura del tri�ngulo: ");
    scanf("%lf", &altura);
    printf("Ingresa el primer lado del tri�ngulo: ");
    scanf("%lf", &a);
    printf("Ingresa el segundo lado del tri�ngulo: ");
    scanf("%lf", &b);
    printf("Ingresa el tercer lado del tri�ngulo: ");
    scanf("%lf", &c);
    printf("�rea: %.2lf\n", (base * altura) / 2);
    printf("Per�metro: %.2lf\n", a + b + c);
}

void calcularCirculo() {
    double radio;
    printf("Ingresa el radio del c�rculo: ");
    scanf("%lf", &radio);
    printf("�rea: %.2lf\n", PI * radio * radio);
    printf("Per�metro (Circunferencia): %.2lf\n", 2 * PI * radio);
}

void calcularTrapecio() {
    double baseMayor, baseMenor, altura, lado1, lado2;
    printf("Ingresa la base mayor del trapecio: ");
    scanf("%lf", &baseMayor);
    printf("Ingresa la base menor del trapecio: ");
    scanf("%lf", &baseMenor);
    printf("Ingresa la altura del trapecio: ");
    scanf("%lf", &altura);
    printf("Ingresa el primer lado del trapecio: ");
    scanf("%lf", &lado1);
    printf("Ingresa el segundo lado del trapecio: ");
    scanf("%lf", &lado2);
    printf("�rea: %.2lf\n", (baseMayor + baseMenor) * altura / 2);
    printf("Per�metro: %.2lf\n", baseMayor + baseMenor + lado1 + lado2);
}

void calcularRombo() {
    double diagonalMayor, diagonalMenor, lado;
    printf("Ingresa la diagonal mayor del rombo: ");
    scanf("%lf", &diagonalMayor);
    printf("Ingresa la diagonal menor del rombo: ");
    scanf("%lf", &diagonalMenor);
    printf("Ingresa el lado del rombo: ");
    scanf("%lf", &lado);
    printf("�rea: %.2lf\n", (diagonalMayor * diagonalMenor) / 2);
    printf("Per�metro: %.2lf\n", 4 * lado);
}

void calcularRomboide() {
    double base, altura, lado;
    printf("Ingresa la base del romboide: ");
    scanf("%lf", &base);
    printf("Ingresa la altura del romboide: ");
    scanf("%lf", &altura);
    printf("Ingresa el lado del romboide: ");
    scanf("%lf", &lado);
    printf("�rea: %.2lf\n", base * altura);
    printf("Per�metro: %.2lf\n", 2 * (base + lado));
}

void calcularCubo() {
    double lado;
    printf("Ingresa el lado del cubo: ");
    scanf("%lf", &lado);
    printf("�rea superficial: %.2lf\n", 6 * lado * lado);
    printf("Volumen: %.2lf\n", lado * lado * lado);
}

void calcularEsfera() {
    double radio;
    printf("Ingresa el radio de la esfera: ");
    scanf("%lf", &radio);
    printf("�rea superficial: %.2lf\n", 4 * PI * radio * radio);
    printf("Volumen: %.2lf\n", (4.0 / 3) * PI * radio * radio * radio);
}

void calcularCilindro() {
    double radio, altura;
    printf("Ingresa el radio del cilindro: ");
    scanf("%lf", &radio);
    printf("Ingresa la altura del cilindro: ");
    scanf("%lf", &altura);
    printf("�rea superficial: %.2lf\n", 2 * PI * radio * (radio + altura));
    printf("Volumen: %.2lf\n", PI * radio * radio * altura);
}

void calcularCono() {
    double radio, altura, generatriz;
    printf("Ingresa el radio del cono: ");
    scanf("%lf", &radio);
    printf("Ingresa la altura del cono: ");
    scanf("%lf", &altura);
    printf("Ingresa la generatriz del cono: ");
    scanf("%lf", &generatriz);
    printf("�rea superficial: %.2lf\n", PI * radio * (radio + generatriz));
    printf("Volumen: %.2lf\n", (1.0 / 3) * PI * radio * radio * altura);
}

void calcularPiramide() {
    double baseArea, altura;
    printf("Ingresa el �rea de la base de la pir�mide: ");
    scanf("%lf", &baseArea);
    printf("Ingresa la altura de la pir�mide: ");
    scanf("%lf", &altura);
    printf("Volumen: %.2lf\n", (1.0 / 3) * baseArea * altura);
}

// Funci�n principal para mostrar el men� y tomar decisiones
int main() {
    int opcion;

    do {
        printf("\nSeleccione una figura geom�trica para calcular el �rea y el per�metro:\n");
        printf("1. Cuadrado\n");
        printf("2. Rect�ngulo\n");
        printf("3. Tri�ngulo\n");
        printf("4. C�rculo\n");
        printf("5. Trapecio\n");
        printf("6. Rombo\n");
        printf("7. Romboide\n");
        printf("8. Cubo\n");
        printf("9. Esfera\n");
        printf("10. Cilindro\n");
        printf("11. Cono\n");
        printf("12. Pir�mide\n");
        printf("0. Salir\n");
        printf("Opci�n: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1: calcularCuadrado(); break;
            case 2: calcularRectangulo(); break;
            case 3: calcularTriangulo(); break;
            case 4: calcularCirculo(); break;
            case 5: calcularTrapecio(); break;
            case 6: calcularRombo(); break;
            case 7: calcularRomboide(); break;
            case 8: calcularCubo(); break;
            case 9: calcularEsfera(); break;
            case 10: calcularCilindro(); break;
            case 11: calcularCono(); break;
            case 12: calcularPiramide(); break;
            case 0: printf("Saliendo...\n"); break;
            default: printf("Opci�n no v�lida. Intenta de nuevo.\n");
        }

    } while (opcion != 0);

    return 0;
}
