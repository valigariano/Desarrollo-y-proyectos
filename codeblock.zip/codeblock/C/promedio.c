#include<stdio.h>
#include<conio.h>

int main() {
    double calificacion, calificacion0, calificacion1, promedio;

    // Leer las calificaciones como n�meros de punto flotante (double)
    printf("Ingresar calificacion 1: ");
    scanf("%lf", &calificacion);
    printf("Ingresar calificacion 2: ");
    scanf("%lf", &calificacion0);
    printf("Ingresar calificacion 3: ");
    scanf("%lf", &calificacion1);

    // Calcular el promedio
    promedio = (calificacion + calificacion0 + calificacion1) / 3;

    // Evaluar el promedio
    if (promedio >= 90 && promedio <= 100) {
        printf("Excelente\n");
    } else if (promedio >= 80 && promedio < 90) {
        printf("Aprobaci�n muy bien\n");
    } else if (promedio >= 70 && promedio < 80) {
        printf("Aprobado\n");
    } else if (promedio >= 60 && promedio < 70) {
        printf("Reprobado\n");
    } else {
        printf("Muy reprobado\n");
    }

    getch(); // Esto es para pausar la salida en algunos compiladores
    return 0;
}
