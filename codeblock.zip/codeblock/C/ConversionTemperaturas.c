#include<stdio.h>
main(){
  int fahrenheit,celsius;
  int bajo,alto, paso;
  bajo=0;
  alto=300;
  paso=20;

  fahrenheit=bajo;
  while (fahrenheit<=alto){

    celsius=5*(fahrenheit-32)/9;
    printf("%d\t%d\n",fahrenheit,celsius);
    fahrenheit=fahrenheit+paso;
  }

}
