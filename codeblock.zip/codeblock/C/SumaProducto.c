#include <stdio.h>
// <conio.h> se omite si no lo necesitas (solo es necesario para compilers antiguos)

int main() {
   double operador, operador0, suma, producto;

   // Solicitar el primer n�mero
   printf("Ingresa un numero: ");
   scanf("%lf", &operador);

   // Solicitar el segundo n�mero
   printf("Ingresa un valor numerico: ");
   scanf("%lf", &operador0);

   // Realizar las operaciones
   suma = operador + operador0;       // Asignaci�n correcta para la suma
   producto = operador * operador0;   // Asignaci�n correcta para el producto

   // Mostrar los resultados
   printf("La suma de los numeros es: %lf\n", suma);
   printf("El producto de los numeros es: %lf\n", producto);

   return 0;
}
