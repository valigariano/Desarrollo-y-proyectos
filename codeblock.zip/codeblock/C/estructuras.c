#include<stdio.h>
#include<conio.h>

int main()
{
    double calificacion,calificacion0,calificacion1,promedio;
     printf("ingresar calificacion:");
        scanf("%d",&calificacion);
     printf("ingresar calificacion:");
        scanf("%d",&calificacion0);
     printf("ingresar calificacion:");
        scanf("%d",&calificacion1);
     promedio=(calificacion+calificacion0+calificacion1)/3;

          if (promedio>=90 && 100)
          {
              printf("Excelente");
          }
         else {

          if (promedio>=80 && 89 )
          {
              printf("Aprobacion muy bien");
          }

          if (promedio>=70)
          {
              printf("Aprobado");
          }
          if ( promedio>=60)
          {
              printf("reprobado");
          }
         }
          getch();

          return 0;
}
