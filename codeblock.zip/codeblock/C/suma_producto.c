#include <stdio.h>
#include<conio.h>

int main(){
   double operador, operador0,suma,producto,resultado;

   printf("Ingresa un numero");

   scanf ("%lf",&operador);

   printf("Ingresa un valor numerico");

  scanf("%lf",&operador0);

    suma: operador+operador0;

    producto:operador*operador;

      printf("La suma de los numeros es");

      printf("%lf",suma);

      printf("\n");

      printf("El producto de los numero es");

      printf("%lf",producto);

       getch();
       return 0;

}
